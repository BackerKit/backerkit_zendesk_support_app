# backerkit_zendesk_support_app

Install the Zendesk tools

`gem install zendesk_apps_tools`

For development

`zat server`

To build a new version

`zat package`
